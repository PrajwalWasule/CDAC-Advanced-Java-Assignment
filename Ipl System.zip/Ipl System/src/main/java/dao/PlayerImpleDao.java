package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import utils.DBUtils;

public class PlayerImpleDao implements PlayerDao{
	private Connection cn;
	private PreparedStatement pst1;
	
	
	
	public PlayerImpleDao() throws SQLException {
		super();
		DBUtils.openConnection();
		pst1=cn.prepareStatement("insert into players values (default,?,?,?,?,?,?)");
		System.out.println("User DAO created !!");
	}

	@Override
	public String updatePlayer(int id) throws SQLException {
		
		return null;
	}

}

package dao;

import java.sql.SQLException;

public interface PlayerDao {
	String updatePlayer(int id) throws SQLException; 
}

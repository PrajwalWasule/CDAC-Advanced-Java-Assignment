package utils;

import java.sql.*;

public class DBUtils {
	private static Connection cn;
	
	public static Connection openConnection() throws /*ClassNotFoundException,*/SQLException
	{
//		Class.forName("com.mysql.cj.jdbc.Driver");
		cn= DriverManager.getConnection(
				"jdbc:mysql://localhost:3306/advjava_rajat?useSSL=false&allowPublicKeyRetrieval=true","root", "root");
		return cn;
	}
}

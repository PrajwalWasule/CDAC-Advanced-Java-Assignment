package dao;


import java.sql.SQLException;
import java.util.List;

import pojos.User;

public interface UserDao {
//add a method to get user details under specific role n dob range
	public List<User> authenticateUsers( String email, String password) throws SQLException;
}
